class FirestoreKeys {
  static const users = "Users";
  static const chats = "Chats";
  static const chatMembersId = "chatMembersId";
  static const messages = "messages";
  static const lastMessage = "lastMessage";
  static const lastMessageTimeStamp = "lastMessageTime";
  static const displayName = "displayName";
  static const email = "email";
  static const uid = "uid";
}
